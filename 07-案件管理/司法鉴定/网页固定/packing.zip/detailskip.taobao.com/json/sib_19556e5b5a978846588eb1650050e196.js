


g_config.RequstPrior='success';	g_config.DynamicStock={
"virtQuantity":"82","holdQuantity":"0","stock":        "82"
        }
;
	g_config.PromoData={
									"def":[
				{		
			type:  "��ĩ������"	,
			 price:"2499.00",			limitTime: "",
			channelkey: "",
			add: "",
			gift: "",
			cart: "true",
			amountRestriction:"",
			isStart:"false"					}			]		}
;
	g_config.vdata.asyncViewer={
	"viewer":{
      	      	"admin":false,"lgin":false,"cc":false,
      	"cartDomain":"cart.taobao.com", "buyDomain":"buy.taobao.com",
      	"bs":""      	,"tkn":"ee58753058367"
  	}
 };
	g_config.PostageFee={
postage:{
	postageType:'applyPostage',
	type:'applyPostage',
	location:'�㶫��ɽ',
	destination:'ɽ���ൺ',
		carriage:'<span>���:&nbsp;���˷�</span>',
		estimation:'',
	dataUrl:'http://delivery.taobao.com/detail/delivery_detail.do?itemId=10630885397&source=cdetail',
	cityId:'370200'
}
};
	    g_config.QrcodeImgUrl='http://gqrcode.alicdn.com/img?type=ci&item_id=10630885397&v=1'
;
