


DT.mods.SKU.GetItemInfo.fire({dummy:false
				,quantity:{
	quanity: 110,
	confirmGoods: 62,
	interval: 30 , 	enabled:true
		,paySuccess: 48
	,paySuccessItems: 24
	,confirmGoodsItems: 57
	,refundCount: 0
	  	    ,filterRecords:false
	  	}
					});
